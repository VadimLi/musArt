package com.example.coversame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.IOException;

import butterknife.BindView;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Response";

    @BindView(R.id.loadApi)
    Button loadApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        loadApi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getHttpResponse();
            }
        });
    }

    public void getHttpResponse() {
        final String url = "https://api.discogs.com/database/search?q=Nirvana";
        final OkHttpClient client = new OkHttpClient();
        final Request request = new Request.Builder()
                .url(url)
                .header("Authorization",
                        "Discogs key=zJhVEHPsCnfHcODdabeJ, " +
                                "secret=aOXGmbOOokJgCUQBqWULCfSvBIMvOyNY")
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                String mMessage = e.getMessage();
                Log.w("failure Response", mMessage);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String mMessage = response.body().string();
                Log.e(TAG, mMessage);
            }
        });
    }

}
